package com.korit.study.ch15;

public class Main {
    public static void main(String[] args) {
        푸들 a = new 푸들("뽀삐");

        a.먹다();
        산책 b = new 말티즈();
    }
}

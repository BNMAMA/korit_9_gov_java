package com.korit.study.ch15;

public class 고양이 extends 동물{
}

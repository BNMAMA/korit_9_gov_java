package com.korit.study.ch15;

public interface 그루밍 {
}

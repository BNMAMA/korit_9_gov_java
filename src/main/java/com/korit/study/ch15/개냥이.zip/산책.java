package com.korit.study.ch15;

public interface 산책 {
    void 산책하다();

}
package com.korit.study.ch15;

public class 말티즈 implements 산책 {

    @Override
    public void 산책하다() {

    }
}

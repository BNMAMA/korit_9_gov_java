package com.korit.study.ch15;

public class 푸들 extends 강아지 {
    푸들(String 이름) {
        super(이름);
        System.out.println("푸들 생성자: " + 이름);
    }
}
